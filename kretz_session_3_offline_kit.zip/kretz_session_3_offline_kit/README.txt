KRETZ AI TRAINING - SESSION 3 OFFLINE KIT
=========================================

Unzip this folder anywhere on your computer and open the files in a web browser.
No internet connection is needed. Start with kretz_ai_hub.html.

kretz_ai_hub.html
    The Kretz AI Hub: goals and milestones, a guided path for bringing any
    AI tool or idea into use, the prompt library, and links to every tool.
    "Download program file" saves goals, milestones and Tool Cards in one
    file; "Load program file" restores them on any computer.

kretz_land_deductions.html
    Land Deductions Evaluator: easements, wetlands, floodplain, soils,
    slope, access and title issues. Map the acres, count each acre once,
    and record the evidence for every percentage.

kretz_session_3.html
    The Session 3 page: the three principles and the built-in tools
    (policy -> procedure -> workflow builder, checklist, AI Tool Card).
    Each tool can save your work as a file and open it again later.

kretz_ai_tool_register.html
    The AI Tool Register. Load AI Tool Card files (.json), see which tools
    are cleared for use, who signs off, and which reviews are due.
    Export the register as JSON (to reload later) or CSV (for Excel,
    SharePoint, or another system).

kretz_ai_tool_register_reference.xlsx
    A reference register in Excel: Register (status and review formulas),
    Change Log, Review Log, Summary, and the nine register requirements
    with a pass/fail decision. Paste register CSV rows into Register A-N.

About saved work
    Cards saved with "Save to register" stay in this browser on this
    computer. To move or back up your work, use the file buttons:
    "Download card file", "Export register (JSON)", "Download file".

These tools are one suggested way to document and manage AI tools.
Rename fields, add custom fields, or move the CSV into whatever system
Kretz prefers. What matters: every tool has an owner, a checklist and a
review date.

Online version: https://willardwonder.github.io/kretz/kretz_session_3.html
